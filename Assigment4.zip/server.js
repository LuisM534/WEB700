/********************************************************************************
*  WEB700 – Assignment 03
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
* 
*  Name: Luis Marquez Student ID:128986247 Date: 04/Oct/2025
*
*  Published URL: https://assigmentweb700-15f62ntrc-luis-projects-477819df.vercel.app
*
********************************************************************************/
const express = require('express');
const path = require('path');
const LegoData = require('./modules/legoSets');
const legoData = new LegoData();

const app = express();
const HTTP_PORT = process.env.PORT || 8080;


app.use(express.static(__dirname + '/public'));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/home.html'));
});


app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/about.html'));
});


app.get('/lego/sets', async (req, res) => {
    try {
        const theme = req.query.theme;
        if (theme) {
            const filteredSets = await legoData.getSetsByTheme(theme);
            res.json(filteredSets);
        } else {
            const allSets = await legoData.getAllSets();
            res.json(allSets);
        }
    } catch (err) {
        res.status(404).json({ message: err });
    }
});


app.get('/lego/sets/:set_num', async (req, res) => {
    try {
        const set = await legoData.getSetByNum(req.params.set_num);
        res.json(set);
    } catch (err) {
        res.status(404).json({ message: err });
    }
});

app.get('/lego/add-test', async (req, res) => {
    const testSet = {
      set_num: '123',
      name: 'testSet name',
      year: '2024',
      theme_id: '366',
      num_parts: '123',
      img_url: 'https://fakeimg.pl/375x375?text=[+Lego+]'
    };
  
    try {
      await legoData.addSet(testSet);
      res.redirect('/lego/sets');
    } catch (err) {
      res.status(422).send(err?.message || 'Set already exists');
    }
  });

app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, '/views/404.html'));
});


legoData.initialize()
    .then(() => {
        app.listen(HTTP_PORT, () => {
            console.log(`Server listening on port ${HTTP_PORT}`);
        });
    })
    .catch((err) => {
        console.error("Initialization failed:", err);
    });
